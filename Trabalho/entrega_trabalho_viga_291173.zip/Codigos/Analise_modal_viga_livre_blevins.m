%  Solução Analitica da Viga Livre-Livre
clear all; close all; clc


%% Definição dos parâmetros variáveis

%    Dados Viga experimental de Proc. Sinais
eta = 0.01;
E0=210e9; % modulo de elasticidade [Pa]
E=E0*(1+1i*eta); % modulo de elasticidade complexo
rho=7800; % densidade [kg/m3]
%E=E0;0

b=13e-3;  % base da seção transversal [m]
h=13e-3;  % altura da seção transversal [m]
L=770e-3;   % comprimento da viga [m]

nmod = 9; % numero de modos

xi = 0.001; % + (0.01 - 0.001) * rand(1, nmod); % coeficiente de amortecimento
%% Definição dos parâmetros constantes
lambda_first_5_positions = [...
    4.73004074;
    7.85320462;
    10.9956078;
    14.1371655;
    17.2787597;
];

% Constantes de normalização sigma_n
sigma_first_5_positions = [...
    0.982502215;   % modo 1 (cosh + cos)
    1.000777312;
    0.999966450;
    1.000001450;
    0.999999937;
];

size_lambda_sigma_initial_vector = length(lambda_first_5_positions);

lambda = zeros(1,nmod);
sigma = zeros(1,nmod);

lambda(1:size_lambda_sigma_initial_vector) = lambda_first_5_positions;
sigma(1:size_lambda_sigma_initial_vector) = sigma_first_5_positions;

if(nmod > size_lambda_sigma_initial_vector)
    for k=size_lambda_sigma_initial_vector + 1:nmod
        lambda(k) = pi*(2*k+1)/2;
        sigma(k) = 1;
    end
end

%% Cálculo das variáveis

m=rho*b*h;   %  massa por unidade de comprimento [kg/m]
I=b*h^3/12;    % momento de inércia
dx=0.001; % discretização do espaço                                                       
x= 0:dx:L; % vetor do espaço discretizado
d=x/L ; % vetor de espaço admensional
size_x = length(x);
phi=zeros(size_x,nmod);
phin=zeros(size_x,nmod);

%% Cálculo da forma dos modos

wn = zeros(1,nmod);
fn = zeros(1,nmod);
for i=1:nmod
    fn(i)= (lambda(i)^2/(2*pi*L^2))*sqrt(E*I/m);   % frequencia natural
    wn(i) = (lambda(i)^2/(L^2))*sqrt(E*I/m);  % Frequência natural angular
    for j=1:length(d)
        phi(j,i)=cosh(lambda(i)*d(j)) + cos(lambda(i)*d(j))...
        -sigma(i)*(sinh(lambda(i)*d(j))+sin(lambda(i)*d(j))); % forma do modo  
    end
    phin(:,i)=phi(:,i)/max(abs(phi(:,i)));  % normalização unitária
end

%% Plot das formas modais
plot_graficos_modais(phi,phin,fn,nmod,d);

%% Cálculo da massa modal

m_modal = zeros(1,nmod);
for i=1:nmod
    for j=1:size_x
        m_modal(i) = m_modal(i) + phi(j,i)^2*dx;
    end
     m_modal(i) = m_modal(i)*m;
end

%% Criacao do loop
tamanho_fila = 9;
nb = 4096;
lines = 1600;
vector_H_analitico = zeros(lines,tamanho_fila);
vector_H_experimental = zeros(lines,tamanho_fila);
vector_Coeff_experimental = zeros(lines,tamanho_fila);
vector_input_experimental = zeros(nb,tamanho_fila);
vector_nome_das_pessoas = ["Natália", "Jefferson", "João", "Pedro", ...
                  "Ivan", "Leonardo", "Lucas", "Davi", "Lamartini"];
frac = zeros(tamanho_fila,1);
% numerador_frac = zeros(1600,tamanho_fila);
% denominador_frac = zeros(1600,tamanho_fila);
for numero_na_fila_medicao=1:tamanho_fila
    
    nome_do_aluno = vector_nome_das_pessoas(numero_na_fila_medicao);
    
    %% Leitura dos arquivos
    [f,frf_experimental,coeff_experimental,t,input_experimental] = read_data_from_files(numero_na_fila_medicao,lines);
    %% Cálculo da FRF Analítica
    distancia_saida = 20e-3; %posição na viga do acelerômetro
    distancia_excitacao = numero_na_fila_medicao*(70e-3) + distancia_saida; %posição na viga da excitação
    pos_vetor_excitacao = ceil(distancia_excitacao/dx);
    pos_vetor_saida = ceil(distancia_saida/dx);
    
    %f = (0:lines-1)*df;
    size_frf = length(f);
    frf_viga = zeros(1,size_frf);
    frf_viga2 = zeros(1,size_frf);
    w= 2*pi*f;  % vetor de frequencias em radianos
    
    for p=1:size_frf
        for j=1:nmod
            numerador = phi(pos_vetor_saida,j)*phi(pos_vetor_excitacao,j);
            denominador = m_modal(j)*((wn(j))^2 - (w(p))^2 + 1i*2*w(p)*wn(j)*xi);
            frf_viga(p) = frf_viga(p) + numerador/denominador;
        end
    end
    
    m_div_s2N_para_g_div_lbf = 9.81./(4.44822); % m/(s^2*N) -> g/lbf
    % Deriva 2 vezes e converte a frf analitica para g/lbf 
    frf_analitica = frf_viga(1:1600).*m_div_s2N_para_g_div_lbf.*(-1j*2*pi*f(1:lines)').^2;
    %frf_analitica = frf_viga(1:1600).*m_div_s2N_para_g_div_lbf.*(-1j*f(1:lines)').^2;
    
    %% Adiciona a frf analitica, experimental, coerencia e input nos vetores
    vector_H_analitico(:,numero_na_fila_medicao) = frf_analitica;
    vector_H_experimental(:,numero_na_fila_medicao) = frf_experimental;
    vector_Coeff_experimental(:,numero_na_fila_medicao) = coeff_experimental;
    vector_input_experimental(:,numero_na_fila_medicao) = input_experimental;
    
    
    %% Plot das FRFs, coeficiente de coerência e entrada
    [frac(numero_na_fila_medicao),numerador_temp,denominador_temp] = plot_graficos_frf(vector_H_analitico(:,numero_na_fila_medicao),vector_H_experimental(:,numero_na_fila_medicao), ...
       vector_Coeff_experimental(:,numero_na_fila_medicao),vector_input_experimental(:,numero_na_fila_medicao), ...
       f,t,nome_do_aluno);
    
    % numerador_frac(:, numero_na_fila_medicao) = numerador_temp;
    % denominador_frac(:, numero_na_fila_medicao) = denominador_temp;

end



%% Encontrando h(t)
% A FRF analítica e experimental foram feitas apenas com frequências
% positivas, porém para reconstruir o sinal também precisamos da frequências negativas
% Sabemos que um |X(f)| qualquer [3 1 2 0 2 1] é uma função par.
% porém geralmente temos ela no formato [0 2 1 3 1 2], isto é,
% primeiro as frequÊncias positivas e depois negativas.
% Também sabemos da propriedade X(-f) = X*(f) {conjugado}
% Exemplo com apenas frequÊncias positivas:
% X(f) = [0 2+i 1-i] 
% X*(f)(2:tamanho de x) = [2-i 1+i] fliplr(X*(f)) = [1+i 2-i]
% X(f) = [X(f) flipr(X*(f))] = [0 2+i 1-i 1+i 2-i]
% X(f) = fftshift(X(f)) = [1+i 2-i 0 2+i 1-i]
% É possível ver que |X(f)| é par. 
% Com as frequências positivas e negativas, temos a ifft


vector_H_analitico_add_f_negativo = [vector_H_analitico ; flipud(conj(vector_H_analitico(2:end,:)))];
vector_H_experimental_add_f_negativo= [vector_H_experimental ; flipud(conj(vector_H_experimental(2:end,:)))];

%% Verifica se as operações estão corretas igualando o abs das frequencias negativas e positivas (ignorando a posição 0)
isAddOfNegativeFrequenciesValid = isAddNegativeFrequenciesValid(vector_H_analitico_add_f_negativo,vector_H_experimental_add_f_negativo)


%% Realiza a ifft e plot dos h(t)
dt = t(2) - t(1);
fa = 1/dt;
vector_h_analitico = ifft(vector_H_analitico_add_f_negativo,[],1);
vector_h_experimental = ifft(vector_H_experimental_add_f_negativo,[],1);

[qtd_linhas_experimental,qtd_colunas_experimental] = size(vector_H_experimental_add_f_negativo);
t = (0:qtd_linhas_experimental-1)*dt;
mse_ht = plot_ht(vector_h_analitico,vector_h_experimental,t,tamanho_fila,vector_nome_das_pessoas);




%% Prony

%prony_array_graficos(vector_h_analitico,vector_h_experimental,tamanho_fila,t,vector_nome_das_pessoas);
[array_A,array_s,order,mse_pronyn,isAnalytical] = prony_vector_graficos(vector_h_analitico,vector_h_experimental,tamanho_fila,t,vector_nome_das_pessoas);

tamanho_fila = 9;

array_A = array_A';
array_wn = abs(array_s);


[l,c] = size(array_wn);
prony_modal = [];%zeros(nmod,tamanho_fila);
prony_modaln = [];%zeros(nmod,tamanho_fila);
for i=1:l
     for j=1:c
        [value, min_idx] = min(abs(array_wn(i,j)/(2*pi) - fn));
        if(abs(value) < 200)
           prony_modal(min_idx,i) = abs(array_A(i,j)); 
        end

     end
end
prony_modal_min = min(prony_modal(:));
prony_modal_max = max(prony_modal(:));
%figure;
%plot(prony_modal)
% prony_modal_norm = 2 * (prony_modal - prony_modal_min) / (prony_modal_max - prony_modal_min) - 1;
distances = (90e-3:70e-3:770e-3*10);
[tamanho_distancia,abelha] = size(prony_modal);
posicoes_phi = zeros(1,tamanho_distancia);
posicoes_phi(1) = 90e-3/dx;
for i=2:tamanho_distancia
    posicoes_phi(i) = posicoes_phi(i-1) + 70e-3/dx;
end


if(isAnalytical)
    string_for_label = "analitico";
    output_folder = '../Imagens/prony_modais/analitico';
else
    string_for_label = "experimental";
    output_folder = '../Imagens/prony_modais/experimental';
end

for i=1:length(fn)
    nome_arquivo = fn(i) +  "_prony_modal.png";
    fig = figure('Name',nome_arquivo);
    hold on;
    plot(distances(1:tamanho_distancia),prony_modal(i,:));
    plot(distances(1:tamanho_distancia),phi(posicoes_phi,i));
    label = "prony" + string_for_label + " f_" + i + "= " + num2str(fn(i)) + " Hz";
    label2 = "analitico f_"+ i + " = " + fn(i) + " Hz";
    legend(label,label2);
    xlabel("x em metros");
    ylabel("Amplitude");
    hold off;
    full_path = fullfile(output_folder, nome_arquivo);
    %print(fig, full_path, '-dpng');
end